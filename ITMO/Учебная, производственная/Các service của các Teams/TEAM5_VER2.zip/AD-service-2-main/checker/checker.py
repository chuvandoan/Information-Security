#!/usr/bin/env python3
import os
import sys
import json
import random
import string
import re
import requests

OK = 101
CORRUPT = 102
MUMBLE = 103
DOWN = 104
CHECKER_ERROR = 110

PORT = int(os.getenv("PORT", "8080"))
TIMEOUT = 5

FLAG_RE = re.compile(r"[A-Z0-9]{31}=")


def cquit(code, public="", private=None):
    """
    Minimal 'checklib'-like behavior:
    - print only one line to stdout (public if set, else private if set)
    - exit with code
    """
    out = ""
    if public:
        out = public
    elif private is not None:
        out = str(private)
    if out:
        sys.stdout.write(out + "\n")
    sys.exit(code)


def rnd_str(n=12):
    alphabet = string.ascii_lowercase + string.digits
    return "".join(random.choice(alphabet) for _ in range(n))


def base_url(ip):
    return f"http://{ip}:{PORT}"


def api_post(ip, path, payload, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.post(base_url(ip) + path, headers=headers, json=payload, timeout=TIMEOUT)
        return r
    except requests.RequestException as e:
        cquit(DOWN, f"Connection error: {e}")


def api_get(ip, path, token=None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.get(base_url(ip) + path, headers=headers, timeout=TIMEOUT)
        return r
    except requests.RequestException as e:
        cquit(DOWN, f"Connection error: {e}")


def register(ip, username, password):
    r = api_post(ip, "/api/register", {"username": username, "password": password})
    if r.status_code != 200:
        cquit(MUMBLE, f"Register failed: {r.status_code}")
    try:
        data = r.json()
    except Exception:
        cquit(MUMBLE, "Bad JSON on register")
    if data.get("status") != "ok":
        cquit(MUMBLE, "Register not ok")


def login(ip, username, password):
    r = api_post(ip, "/api/login", {"username": username, "password": password})
    if r.status_code != 200:
        cquit(MUMBLE, f"Login failed: {r.status_code}")
    try:
        data = r.json()
    except Exception:
        cquit(MUMBLE, "Bad JSON on login")
    token = data.get("token")
    if not token:
        cquit(MUMBLE, "No token")
    return token


def create_recipe(ip, token, dish_name, recipe):
    r = api_post(ip, "/api/recipes", {"dish_name": dish_name, "recipe": recipe}, token=token)
    if r.status_code != 200:
        cquit(MUMBLE, f"Create recipe failed: {r.status_code}")
    try:
        data = r.json()
    except Exception:
        cquit(MUMBLE, "Bad JSON on create recipe")
    recipe_id = data.get("id")
    if not isinstance(recipe_id, int):
        cquit(MUMBLE, "No recipe id")
    return recipe_id


def list_recipes(ip, token):
    r = api_get(ip, "/api/recipes", token=token)
    if r.status_code != 200:
        cquit(MUMBLE, f"List recipes failed: {r.status_code}")
    try:
        data = r.json()
    except Exception:
        cquit(MUMBLE, "Bad JSON on list recipes")
    if not isinstance(data, list):
        cquit(MUMBLE, "Recipes is not list")
    return data


def get_recipe(ip, token, recipe_id):
    r = api_get(ip, f"/api/recipes/{recipe_id}", token=token)
    if r.status_code != 200:
        cquit(MUMBLE, f"Get recipe failed: {r.status_code}")
    try:
        data = r.json()
    except Exception:
        cquit(MUMBLE, "Bad JSON on get recipe")
    return data


def action_check(ip):
    # Healthcheck
    r = api_get(ip, "/health")
    if r.status_code != 200 or r.text.strip() != "ok":
        cquit(MUMBLE, "Healthcheck failed")

    # Register
    u = "chef" + rnd_str(8)
    p = rnd_str(16)
    register(ip, u, p)
    
    # Login
    token = login(ip, u, p)
    
    # Create recipe
    dish = "Dish-" + rnd_str(6)
    recipe_text = f"Ingredients:\n- Test ingredient\n\nInstructions:\n1. Mix\n2. Bake"
    recipe_id = create_recipe(ip, token, dish, recipe_text)
    
    # List recipes
    recipes = list_recipes(ip, token)
    if len(recipes) < 1:
        cquit(MUMBLE, "Recipe not in list")
    
    # Get recipe
    data = get_recipe(ip, token, recipe_id)
    if data.get("dish_name") != dish:
        cquit(MUMBLE, "Wrong dish name")
    if recipe_text not in data.get("recipe", ""):
        cquit(MUMBLE, "Recipe content mismatch")
    
    cquit(OK, "OK")


def action_put(ip, flag):
    username = "chef" + rnd_str(8)
    password = rnd_str(16)

    # Register & login
    register(ip, username, password)
    token = login(ip, username, password)

    # Create recipe with flag
    dishes = ["Pasta Carbonara", "Beef Wellington", "Tiramisu", "Ramen", "Paella"]
    dish_name = random.choice(dishes) + "-" + rnd_str(4)
    
    recipe_text = f"""Secret Recipe for {dish_name}

Ingredients:
- Top secret ingredient: {flag}
- Salt and pepper to taste

Instructions:
1. Prepare ingredients carefully
2. Follow the flag instructions
3. Serve hot

Chef's note: This recipe contains confidential information.
"""
    
    recipe_id = create_recipe(ip, token, dish_name, recipe_text)
    
    # Verify flag stored
    data = get_recipe(ip, token, recipe_id)
    if flag not in data.get("recipe", ""):
        cquit(CORRUPT, "Flag not stored")
    
    # Return flag_id as username:password
    cquit(OK, private=f"{username}:{password}")


def action_get(ip, flag_id, flag):
    if ":" not in flag_id:
        cquit(CHECKER_ERROR, "Bad flag_id format")
    username, password = flag_id.split(":", 1)

    # Login
    token = login(ip, username, password)
    
    # List recipes
    recipes = list_recipes(ip, token)
    if len(recipes) < 1:
        cquit(CORRUPT, "No recipes")

    # Check each recipe for flag
    for r in recipes:
        recipe_id = r.get("id")
        if not isinstance(recipe_id, int):
            continue
        
        data = get_recipe(ip, token, recipe_id)
        recipe_text = data.get("recipe", "")
        if isinstance(recipe_text, str) and flag in recipe_text:
            cquit(OK, "OK")

    cquit(CORRUPT, "Flag not found")


def main():
    if len(sys.argv) < 3:
        cquit(CHECKER_ERROR, "Usage: checker.py (check|put|get) IP ...")

    cmd = sys.argv[1]
    ip = sys.argv[2]

    if cmd == "check":
        action_check(ip)

    elif cmd == "put":
        if len(sys.argv) < 5:
            cquit(CHECKER_ERROR, "PUT args: IP vuln flag")
        flag = sys.argv[4]
        if not FLAG_RE.fullmatch(flag):
            cquit(CHECKER_ERROR, "Bad flag format")
        action_put(ip, flag)

    elif cmd == "get":
        if len(sys.argv) < 5:
            cquit(CHECKER_ERROR, "GET args: IP flag_id flag")
        flag_id = sys.argv[3]
        flag = sys.argv[4]
        if not FLAG_RE.fullmatch(flag):
            cquit(CHECKER_ERROR, "Bad flag format")
        action_get(ip, flag_id, flag)

    else:
        cquit(CHECKER_ERROR, "Unknown command")


if __name__ == "__main__":
    main()
