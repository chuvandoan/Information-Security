package main

import (
	"database/sql"
	"log"
	"net/http"
	"os"
	"time"

	_ "modernc.org/sqlite"

	"recipevault/internal/app"
	"recipevault/internal/httpapi"
)

func main() {
	port := os.Getenv("SERVICE_PORT")
	if port == "" {
		port = "8080"
	}

	db, err := sql.Open("sqlite", "file:/app/data/recipevault.db?_pragma=busy_timeout(5000)&_pragma=journal_mode(WAL)")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	a := app.New(db)
	if err := a.Migrate(); err != nil {
		log.Fatal(err)
	}

	handler := httpapi.NewRouter(a)

	srv := &http.Server{
		Addr:              ":" + port,
		Handler:           httpapi.LogRequests(handler),
		ReadTimeout:       5 * time.Second,
		WriteTimeout:      5 * time.Second,
		IdleTimeout:       30 * time.Second,
		ReadHeaderTimeout: 3 * time.Second,
	}

	log.Printf("listening on :%s", port)
	log.Fatal(srv.ListenAndServe())
}
