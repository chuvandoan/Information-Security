package store

import (
	"database/sql"
	"errors"
)

type Store struct {
	db *sql.DB
}

func New(db *sql.DB) *Store {
	return &Store{db: db}
}

// Users

func (s *Store) CreateUser(username, passhash string) error {
	_, err := s.db.Exec(`INSERT INTO users(username, passhash) VALUES(?, ?)`, username, passhash)
	if err != nil {
		// для sqlite проще не парсить текст ошибки: считаем это "duplicate/exists"
		return ErrDuplicate
	}
	return nil
}

func (s *Store) GetUserAuthByUsername(username string) (uid int64, passhash string, err error) {
	err = s.db.QueryRow(`SELECT id, passhash FROM users WHERE username = ?`, username).Scan(&uid, &passhash)
	if errors.Is(err, sql.ErrNoRows) {
		return 0, "", ErrNotFound
	}
	return uid, passhash, err
}

// Tokens

func (s *Store) CreateToken(token string, uid int64, createdAt int64) error {
	_, err := s.db.Exec(`INSERT INTO tokens(token, user_id, created_at) VALUES(?, ?, ?)`, token, uid, createdAt)
	return err
}

func (s *Store) GetUserIDByToken(token string) (int64, error) {
	var uid int64
	err := s.db.QueryRow(`SELECT user_id FROM tokens WHERE token = ?`, token).Scan(&uid)
	if errors.Is(err, sql.ErrNoRows) {
		return 0, ErrAuth
	}
	return uid, err
}

// Recipes

func (s *Store) CreateRecipe(uid int64, dishName, recipe string, createdAt int64) (int64, error) {
	res, err := s.db.Exec(
		`INSERT INTO recipes(user_id, dish_name, recipe, created_at) VALUES(?, ?, ?, ?)`,
		uid, dishName, recipe, createdAt,
	)
	if err != nil {
		return 0, err
	}
	id, _ := res.LastInsertId()
	return id, nil
}

func (s *Store) ListRecipesByUser(uid int64, limit int) ([]RecipeShort, error) {
	if limit <= 0 || limit > 500 {
		limit = 200
	}
	rows, err := s.db.Query(
		`SELECT id, dish_name, created_at FROM recipes WHERE user_id = ? ORDER BY id DESC LIMIT ?`,
		uid, limit,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	out := make([]RecipeShort, 0, 32)
	for rows.Next() {
		var r RecipeShort
		if err := rows.Scan(&r.ID, &r.DishName, &r.CreatedAt); err != nil {
			return nil, err
		}
		out = append(out, r)
	}
	return out, nil
}

func (s *Store) GetRecipeByID(id int64) (*Recipe, error) {
	var r Recipe
	err := s.db.QueryRow(
		`SELECT id, user_id, dish_name, recipe, created_at FROM recipes WHERE id = ?`,
		id,
	).Scan(&r.ID, &r.UserID, &r.DishName, &r.Recipe, &r.CreatedAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, err
	}
	return &r, nil
}
