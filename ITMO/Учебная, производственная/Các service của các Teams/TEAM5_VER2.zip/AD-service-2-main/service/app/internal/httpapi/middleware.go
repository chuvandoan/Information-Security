package httpapi

import (
	"context"
	"log"
	"net/http"
	"strings"
)

type ctxKey string

const ctxUserID ctxKey = "uid"

func LogRequests(next http.Handler) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		log.Printf("%s %s", r.Method, r.URL.Path)
		next.ServeHTTP(w, r)
	}
}

func (s *Server) auth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		h := r.Header.Get("Authorization")
		if !strings.HasPrefix(h, "Bearer ") {
			writeJSON(w, 401, map[string]string{"error": "no_token"})
			return
		}
		tok := strings.TrimSpace(strings.TrimPrefix(h, "Bearer "))

		uid, err := s.App.Store.GetUserIDByToken(tok)
		if err != nil {
			writeJSON(w, 401, map[string]string{"error": "bad_token"})
			return
		}
		ctx := context.WithValue(r.Context(), ctxUserID, uid)
		next(w, r.WithContext(ctx))
	}
}

func userID(r *http.Request) int64 {
	v := r.Context().Value(ctxUserID)
	if v == nil {
		return 0
	}
	return v.(int64)
}
