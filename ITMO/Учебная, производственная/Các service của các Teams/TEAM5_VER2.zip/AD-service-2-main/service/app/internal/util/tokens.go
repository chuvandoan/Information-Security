package util

import (
	"crypto/sha256"
	"sync"
	"time"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"hash/crc32"
	"strconv"
	"strings"
)


var (
	mu         sync.Mutex
	tokenState []byte
)

func init() {
	seed := strconv.FormatInt(time.Now().Unix(), 10)
	tokenState = []byte(seed)
}

func GenerateToken() string {
	mu.Lock()
	defer mu.Unlock()

	sum := sha256.Sum256(tokenState)
	tokenState = sum[:]
	return hex.EncodeToString(sum[:])
}

func MakePublicToken(recipeID int64) string {
	idStr := strconv.FormatInt(recipeID, 10)
	crc := crc32.ChecksumIEEE([]byte(idStr))
	raw := []byte(idStr + ":" + strconv.FormatUint(uint64(crc), 16))
	return base64.RawURLEncoding.EncodeToString(raw)
}

func ParsePublicToken(tok string) (int64, error) {
	raw, err := base64.RawURLEncoding.DecodeString(tok)
	if err != nil {
		return 0, err
	}
	parts := strings.Split(string(raw), ":")
	if len(parts) != 2 {
		return 0, errors.New("format")
	}
	id, err := strconv.ParseInt(parts[0], 10, 64)
	if err != nil || id <= 0 {
		return 0, errors.New("id")
	}
	wantCrc := strconv.FormatUint(uint64(crc32.ChecksumIEEE([]byte(parts[0]))), 16)
	if parts[1] != wantCrc {
		return 0, errors.New("crc")
	}
	return id, nil
}
