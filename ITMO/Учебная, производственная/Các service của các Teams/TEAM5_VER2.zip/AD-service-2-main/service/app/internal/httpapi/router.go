package httpapi

import (
	"net/http"

	"recipevault/internal/app"
)

type Server struct {
	App *app.App
}

func NewRouter(a *app.App) http.Handler {
	s := &Server{App: a}
	mux := http.NewServeMux()

	mux.HandleFunc("/health", s.handleHealth)

	mux.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("web"))))
	mux.HandleFunc("/", s.handleIndex)

	mux.HandleFunc("/api/register", s.handleRegister)
	mux.HandleFunc("/api/login", s.handleLogin)
	mux.HandleFunc("/api/recipes", s.auth(s.handleRecipes))
	mux.HandleFunc("/api/recipes/", s.auth(s.handleRecipeRoutes))
	mux.HandleFunc("/api/public/", s.handlePublicByToken)

	return mux
}
