package httpapi

import (
	"net/http"
	"strings"
	"time"

	"golang.org/x/crypto/bcrypt"

	"recipevault/internal/store"
	"recipevault/internal/util"
)

type RegisterReq struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

type LoginReq struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

func (s *Server) handleRegister(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeJSON(w, 405, map[string]string{"error": "method"})
		return
	}

	var req RegisterReq
	if err := readJSON(r, &req); err != nil {
		writeJSON(w, 400, map[string]string{"error": "bad_json"})
		return
	}

	req.Username = strings.TrimSpace(req.Username)
	if len(req.Username) < 3 || len(req.Username) > 32 {
		writeJSON(w, 400, map[string]string{"error": "bad_username"})
		return
	}
	if len(req.Password) < 6 || len(req.Password) > 72 {
		writeJSON(w, 400, map[string]string{"error": "bad_password"})
		return
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": "internal"})
		return
	}

	if err := s.App.Store.CreateUser(req.Username, string(hash)); err != nil {
		if err == store.ErrDuplicate {
			writeJSON(w, 409, map[string]string{"error": "exists"})
			return
		}
		writeJSON(w, 500, map[string]string{"error": "db"})
		return
	}

	writeJSON(w, 200, map[string]string{"status": "ok"})
}

func (s *Server) handleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeJSON(w, 405, map[string]string{"error": "method"})
		return
	}

	var req LoginReq
	if err := readJSON(r, &req); err != nil {
		writeJSON(w, 400, map[string]string{"error": "bad_json"})
		return
	}

	req.Username = strings.TrimSpace(req.Username)
	if req.Username == "" || req.Password == "" {
		writeJSON(w, 400, map[string]string{"error": "empty"})
		return
	}

	uid, passhash, err := s.App.Store.GetUserAuthByUsername(req.Username)
	if err != nil {
		if err == store.ErrNotFound {
			writeJSON(w, 401, map[string]string{"error": "auth"})
			return
		}
		writeJSON(w, 500, map[string]string{"error": "db"})
		return
	}

	if err := bcrypt.CompareHashAndPassword([]byte(passhash), []byte(req.Password)); err != nil {
		writeJSON(w, 401, map[string]string{"error": "auth"})
		return
	}

	token := util.GenerateToken()
	if err := s.App.Store.CreateToken(token, uid, time.Now().Unix()); err != nil {
		writeJSON(w, 500, map[string]string{"error": "db"})
		return
	}

	writeJSON(w, 200, map[string]any{"token": token})
}
