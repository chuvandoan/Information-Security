package httpapi

import (
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"recipevault/internal/store"
	"recipevault/internal/util"
)

type RecipeCreateReq struct {
	DishName string `json:"dish_name"`
	Recipe   string `json:"recipe"`
}

func (s *Server) handleRecipes(w http.ResponseWriter, r *http.Request) {
	uid := userID(r)
	if uid == 0 {
		writeJSON(w, 401, map[string]string{"error": "auth"})
		return
	}

	switch r.Method {
	case http.MethodGet:
		recipes, err := s.App.Store.ListRecipesByUser(uid, 200)
		if err != nil {
			writeJSON(w, 500, map[string]string{"error": "db"})
			return
		}

		type RecipeShortResp struct {
			ID        int64  `json:"id"`
			DishName  string `json:"dish_name"`
			CreatedAt int64  `json:"created_at"`
		}
		out := make([]RecipeShortResp, 0, len(recipes))
		for _, r := range recipes {
			out = append(out, RecipeShortResp{ID: r.ID, DishName: r.DishName, CreatedAt: r.CreatedAt})
		}
		writeJSON(w, 200, out)

	case http.MethodPost:
		var req RecipeCreateReq
		if err := readJSON(r, &req); err != nil {
			writeJSON(w, 400, map[string]string{"error": "bad_json"})
			return
		}

		req.DishName = strings.TrimSpace(req.DishName)
		if req.DishName == "" || len(req.DishName) > 128 || len(req.Recipe) == 0 || len(req.Recipe) > 8192 {
			writeJSON(w, 400, map[string]string{"error": "bad_input"})
			return
		}

		id, err := s.App.Store.CreateRecipe(uid, req.DishName, req.Recipe, time.Now().Unix())
		if err != nil {
			writeJSON(w, 500, map[string]string{"error": "db"})
			return
		}
		writeJSON(w, 200, map[string]any{"id": id})

	default:
		writeJSON(w, 405, map[string]string{"error": "method"})
	}
}

func (s *Server) handleRecipeRoutes(w http.ResponseWriter, r *http.Request) {
	uid := userID(r)
	if uid == 0 {
		writeJSON(w, 401, map[string]string{"error": "auth"})
		return
	}

	rest := strings.TrimPrefix(r.URL.Path, "/api/recipes/")
	rest = strings.Trim(rest, "/")
	if rest == "" {
		writeJSON(w, 400, map[string]string{"error": "bad_route"})
		return
	}

	parts := strings.Split(rest, "/")

	if len(parts) == 2 && parts[1] == "share" {
		if r.Method != http.MethodGet {
			writeJSON(w, 405, map[string]string{"error": "method"})
			return
		}
		id, err := parseID(parts[0])
		if err != nil {
			writeJSON(w, 400, map[string]string{"error": "bad_id"})
			return
		}

		recipe, err := s.App.Store.GetRecipeByID(id)
		if err != nil {
			if errors.Is(err, store.ErrNotFound) {
				writeJSON(w, 404, map[string]string{"error": "not_found"})
				return
			}
			writeJSON(w, 500, map[string]string{"error": "db"})
			return
		}
		if recipe.UserID != uid {
			writeJSON(w, 403, map[string]string{"error": "forbidden"})
			return
		}

		writeJSON(w, 200, map[string]any{"token": util.MakePublicToken(id)})
		return
	}

	if len(parts) == 1 {
		if r.Method != http.MethodGet {
			writeJSON(w, 405, map[string]string{"error": "method"})
			return
		}
		id, err := parseID(parts[0])
		if err != nil {
			writeJSON(w, 400, map[string]string{"error": "bad_id"})
			return
		}

		recipe, err := s.App.Store.GetRecipeByID(id)
		if err != nil {
			if errors.Is(err, store.ErrNotFound) {
				writeJSON(w, 404, map[string]string{"error": "not_found"})
				return
			}
			writeJSON(w, 500, map[string]string{"error": "db"})
			return
		}
		if recipe.UserID != uid {
			writeJSON(w, 403, map[string]string{"error": "forbidden"})
			return
		}

		writeJSON(w, 200, map[string]any{
			"id":         recipe.ID,
			"dish_name":  recipe.DishName,
			"recipe":     recipe.Recipe,
			"created_at": recipe.CreatedAt,
		})
		return
	}

	writeJSON(w, 400, map[string]string{"error": "bad_route"})
}

func parseID(s string) (int64, error) {
	id, err := strconv.ParseInt(s, 10, 64)
	if err != nil || id <= 0 {
		return 0, errors.New("bad id")
	}
	return id, nil
}
