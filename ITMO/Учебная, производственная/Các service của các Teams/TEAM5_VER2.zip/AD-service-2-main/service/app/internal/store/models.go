package store

type RecipeShort struct {
	ID        int64
	DishName  string
	CreatedAt int64
}

type Recipe struct {
	ID        int64
	UserID    int64
	DishName  string
	Recipe    string
	CreatedAt int64
}
