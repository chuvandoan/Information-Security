package httpapi

import (
	"errors"
	"net/http"
	"strings"

	"recipevault/internal/store"
	"recipevault/internal/util"
)

func (s *Server) handlePublicByToken(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeJSON(w, 405, map[string]string{"error": "method"})
		return
	}

	tok := strings.TrimPrefix(r.URL.Path, "/api/public/")
	tok = strings.TrimSpace(strings.Trim(tok, "/"))
	if tok == "" {
		writeJSON(w, 400, map[string]string{"error": "bad_token"})
		return
	}

	id, err := util.ParsePublicToken(tok)
	if err != nil {
		writeJSON(w, 400, map[string]string{"error": "bad_token"})
		return
	}

	recipe, err := s.App.Store.GetRecipeByID(id)
	if err != nil {
		if errors.Is(err, store.ErrNotFound) {
			writeJSON(w, 404, map[string]string{"error": "not_found"})
			return
		}
		writeJSON(w, 500, map[string]string{"error": "db"})
		return
	}

	writeJSON(w, 200, map[string]any{
		"id":         recipe.ID,
		"dish_name":  recipe.DishName,
		"recipe":     recipe.Recipe,
		"created_at": recipe.CreatedAt,
		"public":     true,
	})
}
