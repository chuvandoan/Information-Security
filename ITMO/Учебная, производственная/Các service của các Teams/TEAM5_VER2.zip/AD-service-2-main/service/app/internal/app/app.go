package app

import (
	"database/sql"

	"recipevault/internal/store"
)

type App struct {
	Store *store.Store
}

func New(db *sql.DB) *App {
	return &App{Store: store.New(db)}
}

func (a *App) Migrate() error {
	return a.Store.Migrate()
}
