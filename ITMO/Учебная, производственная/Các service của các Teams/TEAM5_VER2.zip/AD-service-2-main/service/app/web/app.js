const $ = (id) => document.getElementById(id);

const state = {
  token: localStorage.getItem("token") || "",
  username: localStorage.getItem("username") || "",
  selectedRecipeId: 0,
  cachedRecipes: [],
};


function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.style.animation = 'slideInRight 0.3s ease-out reverse';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

function setMsg(el, msg, isError = false) {
  el.textContent = msg;
  el.style.color = isError ? "var(--error)" : "var(--pico-muted-color)";
}

async function api(path, opts = {}) {
  const headers = opts.headers || {};
  if (!headers["Content-Type"] && opts.body) headers["Content-Type"] = "application/json";  
  if (state.token) headers["Authorization"] = `Bearer ${state.token}`;
  
  const res = await fetch(path, { ...opts, headers });
  let data = null;
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("application/json")) {
    try { data = await res.json(); } catch { data = null; }
  } else {
    data = await res.text().catch(() => null);
  }
  return { res, data };
}

function showAuth() {
  $("authView").hidden = false;
  $("appView").hidden = true;
  $("navLogout").hidden = true;
  $("whoami").textContent = "";
}

function showApp() {
  $("authView").hidden = true;
  $("appView").hidden = false;
  $("navLogout").hidden = false;
  $("whoami").textContent = state.username ? `Шеф-повар: ${state.username}` : "";
}

function saveSession(token, username) {
  state.token = token;
  state.username = username;
  localStorage.setItem("token", token);
  localStorage.setItem("username", username);
}

function clearSession() {
  state.token = "";
  state.username = "";
  state.selectedRecipeId = 0;
  state.cachedRecipes = [];
  localStorage.removeItem("token");
  localStorage.removeItem("username");
}

function fmtTs(ts) {
  if (!ts) return "";
  try {
    return new Date(ts * 1000).toLocaleString('ru-RU', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return String(ts);
  }
}

function renderRecipes(items) {
  const filter = ($("filter").value || "").toLowerCase();
  const list = $("recipesList");
  list.innerHTML = "";

  const filtered = items.filter(r => (r.dish_name || "").toLowerCase().includes(filter));
  
  if (filtered.length === 0) {
    $("listMsg").textContent = "Рецептов пока нет (или не подходит фильтр).";
    return;
  }
  $("listMsg").textContent = "";

  for (const r of filtered) {
    const el = document.createElement("div");
    el.className = "recipeItem";
    el.onclick = () => openRecipe(r.id);

    const top = document.createElement("div");
    top.className = "recipeTitleLine";

    const dishName = document.createElement("strong");
    dishName.textContent = r.dish_name || "(без названия)";

    const badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = `#${r.id}`;

    top.appendChild(dishName);
    top.appendChild(badge);

    const meta = document.createElement("small");
    meta.className = "muted";
    meta.textContent = r.created_at ? fmtTs(r.created_at) : "";

    el.appendChild(top);
    el.appendChild(meta);
    list.appendChild(el);
  }
}

async function refreshRecipes() {
  const { res, data } = await api("/api/recipes", { method: "GET" });
  if (!res.ok) {
    setMsg($("listMsg"), "Не удалось загрузить рецепты.", true);
    return;
  }
  state.cachedRecipes = Array.isArray(data) ? data : [];
  renderRecipes(state.cachedRecipes);
}

async function openRecipe(id) {
  state.selectedRecipeId = id;
  const { res, data } = await api(`/api/recipes/${id}`, { method: "GET" });
  if (!res.ok) {
    $("recipeView").hidden = true;
    showToast("Не удалось открыть рецепт", "error");
    return;
  }
  
  $("recipeViewTitle").textContent = data.dish_name || "Рецепт";
  $("recipeMeta").textContent = `ID #${data.id} • ${fmtTs(data.created_at)}`;
  $("recipeViewBody").textContent = data.recipe || "";
  $("shareLink").value = "";
  $("recipeView").hidden = false;
  
  window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
}

async function shareRecipe() {
  const id = state.selectedRecipeId;
  if (!id) return;

  const { res, data } = await api(`/api/recipes/${id}/share`, { method: "GET" });
  if (!res.ok) {
    $("shareLink").value = "Ошибка получения ссылки";
    showToast("Не удалось создать публичную ссылку", "error");
    return;
  }
  
  const url = `${location.origin}/api/public/${data.token}`;
  $("shareLink").value = url;
  
  
  try {
    await navigator.clipboard.writeText(url);
    showToast("Ссылка скопирована в буфер обмена!", "success");
  } catch {
    showToast("Ссылка создана", "success");
  }
}

async function health() {
  try {
    const r = await fetch("/health", { method: "GET" });
    $("healthline").textContent = r.ok ? "✅ Сервис работает" : "⚠️ Сервис недоступен";
    $("healthline").style.color = r.ok ? "var(--success)" : "var(--error)";
  } catch {
    $("healthline").textContent = "❌ Сервис недоступен";
    $("healthline").style.color = "var(--error)";
  }
}

async function init() {
  
  $("navHome").onclick = (e) => { 
    e.preventDefault(); 
    window.scrollTo({ top: 0, behavior: "smooth" }); 
  };
  
  $("navLogout").onclick = (e) => {
    e.preventDefault();
    clearSession();
    showAuth();
    showToast("Вы вышли из аккаунта", "success");
  };

  
  $("btnRegister").onclick = async () => {
    const u = $("regUser").value.trim();
    const p = $("regPass").value;
    
    if (u.length < 3) {
      showToast("Username должен быть минимум 3 символа", "error");
      return;
    }
    if (p.length < 6) {
      showToast("Пароль должен быть минимум 6 символов", "error");
      return;
    }
    
    setMsg($("regMsg"), "Регистрация...");
    const { res, data } = await api("/api/register", { 
      method: "POST", 
      body: JSON.stringify({ username: u, password: p })  
    });
    
    if (!res.ok) {
      const errorMsg = data?.error === "exists" ? "Пользователь уже существует" : `Ошибка: ${data?.error || res.status}`;
      setMsg($("regMsg"), errorMsg, true);
      showToast(errorMsg, "error");
      return;
    }
    
    setMsg($("regMsg"), "✅ Аккаунт создан! Теперь войдите.");
    showToast("Регистрация успешна! Теперь войдите", "success");
    $("regUser").value = "";
    $("regPass").value = "";
  };

  
  $("btnLogin").onclick = async () => {
    const u = $("loginUser").value.trim();
    const p = $("loginPass").value;
    
    if (!u || !p) {
      showToast("Заполните username и password", "error");
      return;
    }
    
    setMsg($("loginMsg"), "Вход...");
    const { res, data } = await api("/api/login", { 
      method: "POST", 
      body: JSON.stringify({ username: u, password: p })  
    });
    
    if (!res.ok) {
      const errorMsg = "Неверный username или пароль";
      setMsg($("loginMsg"), errorMsg, true);
      showToast(errorMsg, "error");
      return;
    }
    
    saveSession(data.token, u);
    showApp();
    await refreshRecipes();
    setMsg($("loginMsg"), "");
    showToast(`Добро пожаловать, ${u}!`, "success");
  };

  
  $("btnCreate").onclick = async () => {
    const dishName = $("recipeDishName").value.trim();
    const recipe = $("recipeBody").value;  
    
    if (!dishName) {
      showToast("Введите название блюда", "error");
      return;
    }
    if (!recipe) {
      showToast("Введите рецепт", "error");
      return;
    }
    if (dishName.length > 128) {
      showToast("Название слишком длинное (макс. 128 символов)", "error");
      return;
    }
    if (recipe.length > 8192) {
      showToast("Рецепт слишком длинный (макс. 8192 символа)", "error");
      return;
    }
    
    setMsg($("createMsg"), "Сохранение...");
    const { res, data } = await api("/api/recipes", { 
      method: "POST", 
      body: JSON.stringify({ dish_name: dishName, recipe })  
    });
    
    if (!res.ok) {
      const errorMsg = `Ошибка: ${data?.error || res.status}`;
      setMsg($("createMsg"), errorMsg, true);
      showToast(errorMsg, "error");
      return;
    }
    
    setMsg($("createMsg"), `✅ Сохранено как #${data.id}`);
    showToast(`Рецепт "${dishName}" сохранён!`, "success");
    $("recipeDishName").value = "";
    $("recipeBody").value = "";  
    await refreshRecipes();
  };

  
  $("filter").oninput = () => {
    renderRecipes(state.cachedRecipes);
  };

  
  $("btnCloseRecipe").onclick = () => {
    $("recipeView").hidden = true;
    state.selectedRecipeId = 0;
  };

  $("btnShare").onclick = shareRecipe;

  
  await health();

  if (state.token) {
    showApp();
    await refreshRecipes();
  } else {
    showAuth();
  }
}

init();
