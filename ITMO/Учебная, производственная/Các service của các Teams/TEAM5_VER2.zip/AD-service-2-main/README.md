# RecipeVault 🍳

Сервис для хранения секретных рецептов шеф-поваров. Учебный проект для Attack-Defense соревнований с намеренной уязвимостью в механизме публичных ссылок.

## 🎯 Описание

RecipeVault — веб-приложение для приватного хранения кулинарных рецептов. Пользователи могут:
- Регистрироваться и входить в систему
- Создавать и просматривать рецепты
- Генерировать публичные ссылки для шаринга

**Флаги размещаются** в поле `recipe` документов через чекер.

## 🏗️ Архитектура

### Backend (Go 1.24)
- **Фреймворк**: `net/http` (стандартная библиотека)
- **БД**: SQLite через `modernc.org/sqlite` (pure Go, без CGO)
- **Аутентификация**: Bearer tokens (bcrypt для паролей)
- **Структура**:
  - `cmd/recipevault/main.go` — точка входа
  - `internal/app` — бизнес-логика
  - `internal/store` — работа с БД
  - `internal/httpapi` — HTTP handlers
  - `internal/util` — генерация токенов

### Frontend
- Vanilla JavaScript (без фреймворков)
- Pico.css (classless CSS framework)
- Адаптивный дизайн с анимациями

### База данных
- `users` — username, passhash
- `tokens` — bearer tokens для сессий
- `recipes` — dish_name, recipe, created_at

## 🚀 Запуск

### Docker (рекомендуется для AD)

```bash
cd service
docker-compose up --build
```
Сервис будет доступен на http://localhost:8080

## Структура проекта

```text
service/
├── app/
│   ├── cmd/recipevault/main.go       # Entry point
│   ├── internal/
│   │   ├── app/app.go                # Application layer
│   │   ├── httpapi/
│   │   │   ├── router.go             # Routes
│   │   │   ├── handlers_auth.go      # /api/register, /api/login
│   │   │   ├── handlers_recipes.go   # /api/recipes
│   │   │   ├── handlers_public.go    # /api/public/{token} (VULN)
│   │   │   ├── handlers_misc.go      # /health, /
│   │   │   ├── middleware.go         # auth(), LogRequests()
│   │   │   └── helpers.go            # writeJSON, readJSON
│   │   ├── store/
│   │   │   ├── store.go              # DB queries
│   │   │   ├── models.go             # Recipe, RecipeShort
│   │   │   ├── migrate.go            # Schema
│   │   │   └── errors.go             # ErrNotFound, ErrAuth, etc
│   │   └── util/
│   │       └── tokens.go             # MakePublicToken (VULN)
│   ├── web/
│   │   ├── index.html                # UI
│   │   ├── app.js                    # Frontend logic
│   │   ├── custom.css                # Styles
│   │   └── pico.classless.min.css    # Framework
│   ├── go.mod
│   └── go.sum
├── Dockerfile
└── docker-compose.yml
```

## 🔒 API Endpoints

Публичные

    GET /health — healthcheck

    GET / — главная страница

    POST /api/register — регистрация {username, password}

    POST /api/login — вход {username, password} → {token}

    GET /api/public/{token} — публичный просмотр рецепта ⚠️

Требуют авторизации (Header: Authorization: Bearer {token})

    GET /api/recipes — список рецептов пользователя

    POST /api/recipes — создать рецепт {dish_name, recipe}

    GET /api/recipes/{id} — получить рецепт

    GET /api/recipes/{id}/share — сгенерировать публичную ссылку
